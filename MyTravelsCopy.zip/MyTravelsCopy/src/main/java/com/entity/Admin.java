package com.entity;

public class Admin {
//id, busname, busno, from, to, date, time, seats
	private int id;
	
	private String busname;
	
	private String busno;
	
	private String from;
	
	private String to;
	
	private String date;
	
	private String seats;
	private String price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getBusno() {
		return busno;
	}
	public void setBusno(String busno) {
		this.busno = busno;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Admin [id=" + id + ", busname=" + busname + ", busno=" + busno + ", from=" + from + ", to=" + to
				+ ", date=" + date + ", seats=" + seats + ", price=" + price + "]";
	}
	
}
