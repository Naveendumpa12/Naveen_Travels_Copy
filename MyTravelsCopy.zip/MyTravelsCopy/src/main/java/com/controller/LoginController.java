package com.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.entity.User;
import com.service.LoginService;

@Controller
public class LoginController
{
	@Autowired
	LoginService loginService;

	@RequestMapping("/signup")
	public String redirectToSignUp(HttpServletRequest req, Model model) {
		return "signup";
	}

	@RequestMapping("/signin")
	public String redirectToLogin(HttpServletRequest req, Model model) {
		return "signin";
	}

	/*
	@RequestMapping(path = "/validate-login",method = RequestMethod.POST)
	public String validateLogin(HttpServletRequest req, Model model) {
		System.out.println("Validater Invoked --");String userFirstName = req.getParameter("firstname");
		String userLastName = req.getParameter("lastname");
		String passWord = req.getParameter("password");
		System.out.println(userFirstName);
		System.out.println(userLastName);
		System.out.println(passWord);

		if (userFirstName.equals("User") &&userLastName.equals("User") && passWord.equals("User")) {
			model.addAttribute("firstname", userFirstName);
			return "travel-book";
		} 
		 else {
			return "invalidLogin";
		}
	}
	*/
	
	
	@RequestMapping("/validate-login")
	public String performLogin(@RequestParam("firstname")String firstname,@RequestParam("password")String password, Model model)
	{
		User users = loginService.verifyUser(firstname,password);
		/*To Transfer employee object from controller to view (Backend to Frontend)*/
		//model.addAttribute("information", users);
		if (users!=null) 
		{
			 
			User u1=new User();
			System.out.println(users.getFirstname());
			System.out.println(users.getLastname());
			model.addAttribute("abc",users.getFirstname());
			model.addAttribute("abd", users.getLastname());
			return "travel-book";
		} 
		 else {
			return "invalidLogin";
		}
	}

	
	@RequestMapping(path =   "/create-user",method = RequestMethod.POST)
	public String createUser(@ModelAttribute()User user,Model model) {
		model.addAttribute("abc",user.getFirstname());
		model.addAttribute("abd", user.getLastname());
		return "travel-book";
		
		/* Data front end to JAVA
		 * 
		 * 
		String firstname = incomingRequest.getParameter("firstname");
		String lastname = incomingRequest.getParameter("lastname");
		String gender = incomingRequest.getParameter("gender");
		String mobileno = incomingRequest.getParameter("mobileno");
		
		String email = incomingRequest.getParameter("email");
		String password = incomingRequest.getParameter("password");
		String confirmPassword = incomingRequest.getParameter("confirm-password");
		String dob = incomingRequest.getParameter("dob")
		User user=new User(0, firstname, lastname, gender,mobileno, email, password,confirmPassword);
		loginService.signUpUser(user);
		System.out.println("*************** User Details are ***************************");
		System.out.println(String.format(" First Name : %s \n Last Name : %s \n Gender : %s \n Mobile No : %s \n Date of Birth : %s \n Email : %s \n Password : %s \n Confirm Password : %s \n",
						firstname,lastname,gender,mobileno,dob,email, password, confirmPassword));
	
		
		*/
	}
}
