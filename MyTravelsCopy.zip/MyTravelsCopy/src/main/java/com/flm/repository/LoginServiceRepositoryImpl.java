package com.flm.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.entity.User;

@Repository
public class LoginServiceRepositoryImpl implements LoginServiceRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public void singUpUser(User user) {
		int rowCount = jdbcTemplate.update(
				"INSERT INTO travels_copy (`firstname`,`lastname`,`mobileno`,`gender`,`email`,`password`,`confirm_password`) VALUES (?, ?, ?, ?, ?, ?, ?)",
				user.getFirstname(), user.getLastname(), user.getMobileno(), user.getGender(), user.getEmail(),
				user.getPassword(), user.getConfirmpassword());
		System.out.println("Rows INserted " + rowCount);
	}

	@Override
	public User verifingUser(String firstname, String password) {
		// TODO Auto-generated method stub
		String query = "select * from travels_copy where firstname = ? and password=?";
		RowMapper<User> rm = new RowMapperImple();
		try {
			User user = jdbcTemplate.queryForObject(query, rm, firstname, password);
			return user;
		} catch (Exception e) {
			return null;
		}
	}
}
