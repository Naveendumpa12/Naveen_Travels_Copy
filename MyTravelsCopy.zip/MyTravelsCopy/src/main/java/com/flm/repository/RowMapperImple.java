package com.flm.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.entity.User;

public class RowMapperImple implements RowMapper<User> 
{

	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		User user = new User();
		
//		employee.setEmpId(rs.getInt("empId"));
//		employee.setName(rs.getString("empName"));
//		employee.setSalary(rs.getDouble("empSal"));
//		employee.setDeptNo(rs.getInt("deptNo"));
		user.setFirstname(rs.getString("firstname"));
		user.setLastname(rs.getString("lastname"));
		user.setPassword(rs.getString("password"));
		return user;
	}
}
