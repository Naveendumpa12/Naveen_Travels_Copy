package com.flm.repository;

import com.entity.User;

public interface LoginServiceRepository 
{
	void singUpUser(User user);
	User verifingUser(String firstname,String password);
}
